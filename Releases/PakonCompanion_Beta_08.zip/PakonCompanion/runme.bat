if not exist "%APPDATA%\Subspace\" mkdir "%APPDATA%\Subspace\"
xcopy /y PakonCompanion.exe              "%APPDATA%\Subspace\"
xcopy /y LICENSE-KEY.txt                 "%APPDATA%\Subspace\"
xcopy /y *.dll                           "%APPDATA%\Subspace\"
c:
cd "%APPDATA%\Subspace"
"%APPDATA%\Subspace\PakonCompanion.exe"
